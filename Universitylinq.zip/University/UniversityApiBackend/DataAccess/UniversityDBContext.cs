﻿using Microsoft.EntityFrameworkCore;
using UniversityApiBackend.Models;
using UniversityApiBackend.Models.DataModels;

namespace UniversityApiBackend.DataAccess
{
    public class UniversityDBContext:DbContext
    {

        // Add DBSets (Tables of our  Data base)
        public DbSet<User>? Users { get; set; }
        public DbSet<Course>? Courses { get; set; }
        public DbSet<Chapter>? Chapters { get; set; }
        public DbSet<Category>? Categories { get; set; }
        public DbSet<Student>? Students { get; set; }

        public UniversityDBContext(DbContextOptions<UniversityDBContext> options) : base(options)
        {

        }

        public UniversityDBContext()
        {
        }
    }
}
