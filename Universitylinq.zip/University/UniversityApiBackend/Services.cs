﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UniversityApiBackend.DataAccess;
using UniversityApiBackend.Models.DataModels;

namespace UniversityApiBackend
{
    public class Services
    {

        //private readonly UniversityDBContext context = new UniversityDBContext();

        static public void LinQ()
        {

            using (var context = new UniversityDBContext())
            {

                var ejercicio1 = context.Users.Where(x => x.Email == "Email");

                var ejercicio2 = context.Students.Where(x => (x.Dob - DateTime.Today).TotalHours >= 18);

                var ejercicio3 = from element in context.Students
                                 join secondElement in context.Courses
                                 on element.Id equals secondElement.Id
                                 select new { element, secondElement };

                var ejercicio4 = from element in context.Students
                                 join secondElement in context.Courses.Where(x => x.level == Level.Basic)
                                 on element.Id equals secondElement.Id
                                 select new { element, secondElement };

                var ejercicio5 = from element in context.Courses.Where(x => x.level == Level.Basic)
                                 join secondElement in context.Categories.Where(x => x.Name == "Example")
                                 on element.Id equals secondElement.Id
                                 select new { element, secondElement };

                var ejercicio6 = from secondElement in context.Courses
                                  join element in context.Students
                                  on secondElement.Id equals element.Id
                                  into temporalList
                                  from temporalElement in temporalList.DefaultIfEmpty()
                                 where secondElement.Id != temporalElement.Id
                                 select new { element = secondElement };

            }

        }

    }

}
