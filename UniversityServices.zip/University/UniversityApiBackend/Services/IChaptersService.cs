﻿namespace UniversityApiBackend.Services
{
    public interface IChaptersService
    {
    }
}
