﻿namespace UniversityApiBackend.Services
{
    public interface IUsersService
    {
    }
}
