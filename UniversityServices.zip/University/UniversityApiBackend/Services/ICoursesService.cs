﻿using UniversityApiBackend.Models.DataModels;

namespace UniversityApiBackend.Services
{
    public interface ICoursesService
    {
        IEnumerable<Student> GetStudentsFromCourse();
        IEnumerable<Student> GetChapterFromCourse();
        IEnumerable<Student> GetCourseWithNoChapter();
        IEnumerable<Student> GetCourseWithCategory();
    }
}
