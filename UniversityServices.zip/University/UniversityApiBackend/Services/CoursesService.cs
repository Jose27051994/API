﻿namespace UniversityApiBackend.Services
{
    public class CoursesService
    {
    }
}
