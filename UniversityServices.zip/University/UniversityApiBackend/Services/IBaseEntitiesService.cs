﻿namespace UniversityApiBackend.Services
{
    public interface IBaseEntitiesService
    {
    }
}
