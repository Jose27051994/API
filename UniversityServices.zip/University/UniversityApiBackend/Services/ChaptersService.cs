﻿namespace UniversityApiBackend.Services
{
    public class ChaptersService
    {
    }
}
