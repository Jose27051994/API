﻿namespace UniversityApiBackend.Services
{
    public interface ICategoriesService
    {
    }
}
